# Flor d'Aroma — Palma de Mallorca

Sitio web completo de la floristería Flor d'Aroma. 6 páginas: Inicio, Nosotros,
Servicios, Catálogo, Contacto y Tienda Online.

## Tecnología

- React 19 + TanStack Start (vite como bundler)
- TanStack Router (ficheros de ruta en `src/routes`)
- Tailwind CSS v4 (los colores están en `src/styles.css`)
- TypeScript

## Cómo arrancarlo

Necesitas Node.js 20+ y Bun (o npm).

```bash
bun install      # o: npm install
bun run dev      # o: npm run dev
```

Abre la URL que te muestre la terminal (normalmente http://localhost:8080).

Para generar la versión final:

```bash
bun run build
bun run preview
```

## Dónde está cada cosa

| Quieres cambiar... | Ve a |
| --- | --- |
| Colores y tipografías | `src/styles.css` (bloque `:root`) |
| Menú de arriba | `src/components/Header.tsx` |
| Pie de página | `src/components/Footer.tsx` |
| Página de inicio | `src/routes/index.tsx` |
| Nosotros | `src/routes/about.tsx` |
| Servicios y precios | `src/routes/services.tsx` |
| Productos del catálogo | `src/routes/catalog.tsx` |
| Formulario de contacto | `src/routes/contact.tsx` |
| Tienda Online | `src/routes/shop.tsx` |
| Textos de búsqueda (SEO) | cada fichero de ruta, al principio (`head`) |
| Fotos | `src/assets/` |
| Datos de contacto y horario | `src/components/Footer.tsx` |

## Fotos

Las imágenes están en `src/assets/`. Son las que genera el proyecto;
sustitúyelas por las tuyas manteniendo el mismo nombre de fichero y no hará
falta tocar nada más.

## Notas

- Los datos de contacto (dirección, teléfono, email) y el horario son de muestra:
  cámbialos por los reales en `src/components/Footer.tsx` y en `src/routes/contact.tsx`.
- No hay base de datos ni carrito real: la Tienda Online dirige al catálogo y al
  formulario de contacto.
