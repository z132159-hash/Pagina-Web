import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MapPin, Clock, Phone, Mail, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contacto | Flor d'Aroma" },
      { name: "description", content: "Contacta con Flor d'Aroma, floristería en Palma. Teléfono, email, WhatsApp y formulario." },
      { property: "og:title", content: "Contacto | Flor d'Aroma" },
      { property: "og:description", content: "Contacta con Flor d'Aroma, floristería en Palma." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [form, setForm] = useState({ nombre: "", email: "", mensaje: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("¡Mensaje enviado! Te contactaremos pronto.");
    setForm({ nombre: "", email: "", mensaje: "" });
  };

  const contactInfo = [
    { icon: MapPin, title: "Dirección", value: "Calle de ejemplo, Palma (Baleares)" },
    { icon: Clock, title: "Horario", value: "Lun–Vie: 9:00–20:00 · Sáb: 9:00–14:00" },
    { icon: Phone, title: "Teléfono", value: "971 000 000" },
    { icon: Mail, title: "Email", value: "info@flordaroma.com" },
    { icon: MessageCircle, title: "WhatsApp", value: "Haz tu pedido rápido por WhatsApp" },
  ];

  return (
    <div className="pt-20 sm:pt-24">
      <section className="py-20 sm:py-28 bg-card border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="font-display text-xs tracking-[0.3em] text-primary mb-4">ESCRÍBENOS</p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-[0.95]">
            Contacto
          </h1>
          <div className="mt-6 w-16 h-0.5 bg-primary" />
        </div>
      </section>

      <section className="py-20 sm:py-28 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Info */}
            <div>
              <p className="font-display text-xs tracking-[0.3em] text-primary mb-8">INFORMACIÓN</p>
              <div className="space-y-8">
                {contactInfo.map((c) => (
                  <div key={c.title} className="flex items-start gap-4">
                    <c.icon className="w-5 h-5 text-primary mt-0.5 shrink-0" />
                    <div>
                      <h3 className="font-display text-sm tracking-wider text-foreground">{c.title}</h3>
                      <p className="text-muted-foreground text-sm mt-0.5">{c.value}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Form */}
            <div>
              <p className="font-display text-xs tracking-[0.3em] text-primary mb-8">FORMULARIO</p>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="nombre" className="block text-xs font-display tracking-[0.15em] text-muted-foreground uppercase mb-2">Nombre</label>
                  <input
                    id="nombre"
                    type="text"
                    required
                    value={form.nombre}
                    onChange={(e) => setForm({ ...form, nombre: e.target.value })}
                    className="w-full px-4 py-3 bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors font-body"
                    placeholder="Tu nombre"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-xs font-display tracking-[0.15em] text-muted-foreground uppercase mb-2">Email</label>
                  <input
                    id="email"
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="w-full px-4 py-3 bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors font-body"
                    placeholder="tu@email.com"
                  />
                </div>
                <div>
                  <label htmlFor="mensaje" className="block text-xs font-display tracking-[0.15em] text-muted-foreground uppercase mb-2">Mensaje</label>
                  <textarea
                    id="mensaje"
                    required
                    rows={5}
                    value={form.mensaje}
                    onChange={(e) => setForm({ ...form, mensaje: e.target.value })}
                    className="w-full px-4 py-3 bg-card border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary transition-colors resize-none font-body"
                    placeholder="¿En qué podemos ayudarte?"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full px-10 py-4 bg-primary text-primary-foreground font-display font-bold text-xs tracking-[0.2em] uppercase hover:bg-primary/90 transition-colors"
                >
                  Enviar mensaje
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
