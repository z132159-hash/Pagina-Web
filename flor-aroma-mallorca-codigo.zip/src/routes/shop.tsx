import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/shop")({
  head: () => ({
    meta: [
      { title: "Tienda Online | Flor d'Aroma" },
      { name: "description", content: "Compra flores online en Palma. Ramos, plantas y decoración floral con entrega a domicilio." },
      { property: "og:title", content: "Tienda Online | Flor d'Aroma" },
      { property: "og:description", content: "Compra flores online en Palma con entrega a domicilio." },
    ],
  }),
  component: ShopPage,
});

function ShopPage() {
  return (
    <div className="pt-20 sm:pt-24">
      <section className="py-28 sm:py-40 bg-card border-b border-border">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="font-display text-xs tracking-[0.3em] text-primary mb-4">COMPRA ONLINE</p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-[0.95]">
            Tienda Online
          </h1>
          <div className="mt-6 w-16 h-0.5 bg-primary mx-auto" />
          <p className="mt-8 text-lg text-foreground/70 font-body leading-relaxed max-w-xl mx-auto">
            Compra tus flores favoritas de forma rápida y sencilla. Selecciona tu producto, consulta disponibilidad y realiza tu pedido fácilmente.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/catalog"
              className="inline-flex items-center justify-center px-10 py-4 bg-primary text-primary-foreground font-display font-bold text-xs tracking-[0.2em] uppercase hover:bg-primary/90 transition-colors"
            >
              Ver catálogo
            </Link>
            <Link
              to="/contact"
              className="inline-flex items-center justify-center px-10 py-4 border border-foreground/30 text-foreground font-display font-bold text-xs tracking-[0.2em] uppercase hover:border-primary hover:text-primary transition-colors"
            >
              Comprar ahora
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
