import { createFileRoute, Link } from "@tanstack/react-router";
import ramoRomantico from "@/assets/ramo-romantico.jpg";
import ramoPrimaveral from "@/assets/ramo-primaveral.jpg";
import ramoGirasoles from "@/assets/ramo-girasoles.jpg";
import centroFloral from "@/assets/centro-floral.jpg";
import plantaDecorativa from "@/assets/planta-decorativa.jpg";
import ramoPersonalizado from "@/assets/ramo-personalizado.jpg";

export const Route = createFileRoute("/catalog")({
  head: () => ({
    meta: [
      { title: "Catálogo de Flores | Flor d'Aroma" },
      { name: "description", content: "Explora nuestro catálogo de ramos, centros florales y plantas. Floristería en Palma." },
      { property: "og:title", content: "Catálogo de Flores | Flor d'Aroma" },
      { property: "og:description", content: "Explora nuestro catálogo de ramos, centros florales y plantas." },
    ],
  }),
  component: CatalogPage,
});

const products = [
  { name: "Ramo romántico", desc: "Rosas rojas clásicas para ocasiones especiales.", price: "35€", img: ramoRomantico },
  { name: "Ramo primaveral", desc: "Mezcla de flores coloridas y frescas.", price: "30€", img: ramoPrimaveral },
  { name: "Ramo girasoles", desc: "Alegre y luminoso, perfecto para regalar.", price: "28€", img: ramoGirasoles },
  { name: "Centro floral elegante", desc: "Ideal para mesas y decoración.", price: "45€", img: centroFloral },
  { name: "Planta decorativa", desc: "Planta natural para interiores.", price: "20€", img: plantaDecorativa },
  { name: "Ramo personalizado", desc: "Diseñado según tus preferencias.", price: "Desde 40€", img: ramoPersonalizado },
];

function CatalogPage() {
  return (
    <div className="pt-20 sm:pt-24">
      <section className="py-20 sm:py-28 bg-card border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="font-display text-xs tracking-[0.3em] text-primary mb-4">NUESTRA SELECCIÓN</p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-[0.95]">
            Catálogo
          </h1>
          <div className="mt-6 w-16 h-0.5 bg-primary" />
        </div>
      </section>

      <section className="py-20 sm:py-28 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
            {products.map((p) => (
              <div key={p.name} className="bg-background group">
                <div className="aspect-square overflow-hidden">
                  <img
                    src={p.img}
                    alt={p.name}
                    loading="lazy"
                    width={640}
                    height={640}
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                  />
                </div>
                <div className="p-6 sm:p-8">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="font-display text-lg font-semibold text-foreground">{p.name}</h2>
                      <p className="mt-1 text-sm text-muted-foreground">{p.desc}</p>
                    </div>
                    <span className="font-display text-lg font-bold text-primary shrink-0">{p.price}</span>
                  </div>
                  <Link
                    to="/contact"
                    className="mt-4 inline-block text-xs font-display tracking-[0.2em] text-primary hover:text-primary/80 transition-colors uppercase"
                  >
                    Consultar disponibilidad →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
