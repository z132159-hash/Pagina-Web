import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Servicios Florales | Flor d'Aroma" },
      { name: "description", content: "Ramos, decoración de eventos, bodas, plantas y entrega a domicilio en Palma." },
      { property: "og:title", content: "Servicios Florales | Flor d'Aroma" },
      { property: "og:description", content: "Ramos, decoración de eventos, bodas, plantas y entrega a domicilio en Palma." },
    ],
  }),
  component: ServicesPage,
});

const services = [
  { num: "01", title: "Ramos de flores frescas", desc: "Diseños personalizados con flores de temporada.", price: "Desde 25€" },
  { num: "02", title: "Decoración para eventos", desc: "Decoración floral para celebraciones y eventos.", price: "Desde 120€" },
  { num: "03", title: "Bodas", desc: "Diseño floral completo para bodas (ramos, centros, decoración).", price: "Desde 300€" },
  { num: "04", title: "Plantas de interior y exterior", desc: "Gran variedad de plantas decorativas.", price: "Desde 15€" },
  { num: "05", title: "Entrega a domicilio", desc: "Servicio rápido en Palma y alrededores.", price: "Desde 5€" },
];

function ServicesPage() {
  return (
    <div className="pt-20 sm:pt-24">
      <section className="py-20 sm:py-28 bg-card border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="font-display text-xs tracking-[0.3em] text-primary mb-4">LO QUE OFRECEMOS</p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-[0.95]">
            Nuestros<br />Servicios
          </h1>
          <div className="mt-6 w-16 h-0.5 bg-primary" />
        </div>
      </section>

      <section className="bg-background">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          {services.map((s, i) => (
            <div
              key={s.num}
              className={`flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-8 py-10 sm:py-14 ${i < services.length - 1 ? 'border-b border-border' : ''}`}
            >
              <span className="font-display text-4xl font-bold text-primary/20 shrink-0">{s.num}</span>
              <div className="flex-1">
                <h2 className="font-display text-xl sm:text-2xl font-semibold text-foreground">{s.title}</h2>
                <p className="mt-1 text-muted-foreground">{s.desc}</p>
              </div>
              <span className="font-display text-lg font-bold text-primary shrink-0">{s.price}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="py-16 bg-card border-t border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Link
            to="/contact"
            className="inline-flex items-center justify-center px-10 py-4 bg-primary text-primary-foreground font-display font-bold text-xs tracking-[0.2em] uppercase hover:bg-primary/90 transition-colors"
          >
            Solicitar presupuesto
          </Link>
        </div>
      </section>
    </div>
  );
}
