import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "Sobre Nosotros | Flor d'Aroma" },
      { name: "description", content: "Conoce la historia de Flor d'Aroma, floristería en Palma desde 1998." },
      { property: "og:title", content: "Sobre Nosotros | Flor d'Aroma" },
      { property: "og:description", content: "Conoce la historia de Flor d'Aroma, floristería en Palma desde 1998." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <div className="pt-20 sm:pt-24">
      {/* Hero */}
      <section className="py-20 sm:py-28 bg-card border-b border-border">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="font-display text-xs tracking-[0.3em] text-primary mb-4">NUESTRA HISTORIA</p>
          <h1 className="font-display text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground leading-[0.95]">
            Sobre<br />Flor d'Aroma
          </h1>
          <div className="mt-6 w-16 h-0.5 bg-primary" />
          <p className="mt-8 text-lg text-foreground/70 leading-relaxed max-w-2xl">
            Flor d'Aroma nació en 1998 en Palma con el objetivo de ofrecer flores frescas y diseños florales de calidad. Desde entonces, hemos ayudado a cientos de clientes a expresar emociones a través de nuestros ramos y decoraciones.
          </p>
        </div>
      </section>

      {/* Values grid */}
      <section className="py-20 sm:py-28 bg-background">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="font-display text-xs tracking-[0.3em] text-primary mb-2">NUESTROS PILARES</p>
          <h2 className="font-display text-3xl font-bold text-foreground mb-12">Valores</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-border">
            {[
              { num: "01", title: "Calidad en cada detalle", desc: "Seleccionamos las mejores flores cada día" },
              { num: "02", title: "Atención personalizada", desc: "Cada cliente es único para nosotros" },
              { num: "03", title: "Creatividad floral", desc: "Diseños que rompen lo convencional" },
              { num: "04", title: "Cercanía con el cliente", desc: "Relaciones duraderas basadas en confianza" },
            ].map((v) => (
              <div key={v.num} className="bg-background p-8 sm:p-10">
                <span className="font-display text-4xl font-bold text-primary/60">{v.num}</span>
                <h3 className="mt-4 font-display text-lg font-semibold text-foreground">{v.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 sm:py-28 bg-card border-t border-border">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="font-display text-xs tracking-[0.3em] text-primary mb-4">MISIÓN</p>
          <blockquote className="font-display text-2xl sm:text-3xl font-light text-foreground leading-snug normal-case" style={{ textTransform: 'none' }}>
            "Crear arreglos florales únicos que transmitan emociones y acompañen los momentos más importantes de nuestros clientes."
          </blockquote>
          <div className="mt-8 w-16 h-0.5 bg-primary mx-auto" />
        </div>
      </section>
    </div>
  );
}
