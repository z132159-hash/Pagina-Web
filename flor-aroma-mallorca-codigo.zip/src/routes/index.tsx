import { createFileRoute, Link } from "@tanstack/react-router";
import heroImage from "@/assets/hero-dark.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Floristería en Palma | Flor d'Aroma" },
      { name: "description", content: "Floristería en Palma con ramos, plantas y decoración floral para bodas y eventos. Entrega rápida a domicilio." },
      { name: "keywords", content: "floristería Palma, ramos de flores, flores a domicilio, bodas flores, plantas Palma" },
      { property: "og:title", content: "Floristería en Palma | Flor d'Aroma" },
      { property: "og:description", content: "Floristería en Palma con ramos, plantas y decoración floral para bodas y eventos." },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <div>
      {/* Hero - full bleed dark */}
      <section className="relative min-h-screen flex items-end">
        <div className="absolute inset-0">
          <img src={heroImage} alt="Arreglo floral dramático" className="w-full h-full object-cover" width={1920} height={1080} />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20 sm:pb-32 w-full">
          <div className="max-w-3xl">
            <p className="font-display text-xs tracking-[0.3em] text-primary mb-4">DESDE 1998 · PALMA DE MALLORCA</p>
            <h1 className="font-display text-5xl sm:text-6xl lg:text-8xl font-bold text-foreground leading-[0.9] tracking-tight">
              Flor<br />d'Aroma
            </h1>
            <div className="mt-6 w-16 h-0.5 bg-primary" />
            <p className="mt-6 text-lg sm:text-xl text-foreground/70 font-body leading-relaxed max-w-xl">
              Creamos emociones a través de flores frescas y diseños únicos. Ramos, bodas y decoración floral personalizada.
            </p>
            <p className="mt-4 text-primary italic font-body text-base">
              "Cada flor cuenta una historia, déjanos crear la tuya."
            </p>
            <div className="mt-10 flex flex-col sm:flex-row gap-4">
              <Link
                to="/catalog"
                className="inline-flex items-center justify-center px-10 py-4 bg-primary text-primary-foreground font-display font-bold text-xs tracking-[0.2em] uppercase hover:bg-primary/90 transition-colors"
              >
                Ver catálogo
              </Link>
              <Link
                to="/contact"
                className="inline-flex items-center justify-center px-10 py-4 border border-foreground/30 text-foreground font-display font-bold text-xs tracking-[0.2em] uppercase hover:border-primary hover:text-primary transition-colors"
              >
                Contáctanos
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats bar */}
      <section className="bg-card border-y border-border">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-border">
            {[
              { num: "25+", label: "Años de experiencia" },
              { num: "500+", label: "Bodas realizadas" },
              { num: "100%", label: "Flores frescas" },
              { num: "24h", label: "Entrega express" },
            ].map((s) => (
              <div key={s.label} className="py-8 sm:py-12 text-center">
                <span className="font-display text-3xl sm:text-4xl font-bold text-primary">{s.num}</span>
                <p className="mt-1 text-xs font-display tracking-[0.15em] text-muted-foreground uppercase">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services preview */}
      <section className="py-20 sm:py-28 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-start sm:items-end justify-between mb-12">
            <div>
              <p className="font-display text-xs tracking-[0.3em] text-primary mb-2">LO QUE HACEMOS</p>
              <h2 className="font-display text-3xl sm:text-4xl font-bold text-foreground">Nuestros Servicios</h2>
            </div>
            <Link to="/services" className="mt-4 sm:mt-0 text-xs font-display tracking-[0.2em] text-primary hover:text-primary/80 transition-colors uppercase">
              Ver todos →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
            {[
              { title: "Ramos frescos", price: "Desde 25€" },
              { title: "Decoración eventos", price: "Desde 120€" },
              { title: "Bodas", price: "Desde 300€" },
              { title: "Plantas", price: "Desde 15€" },
              { title: "Entrega a domicilio", price: "Desde 5€" },
              { title: "Diseño personalizado", price: "Consultar" },
            ].map((item) => (
              <div key={item.title} className="bg-background p-8 sm:p-10 group hover:bg-card transition-colors">
                <h3 className="font-display text-lg font-semibold text-foreground group-hover:text-primary transition-colors">{item.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{item.price}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
