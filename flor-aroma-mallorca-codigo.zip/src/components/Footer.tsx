import { Link } from "@tanstack/react-router";

export function Footer() {
  return (
    <footer className="bg-card border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="font-display text-2xl font-bold tracking-widest text-primary mb-4">Flor d'Aroma</h3>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Arte floral desde 1998. Palma de Mallorca.
            </p>
          </div>
          <div>
            <h4 className="font-display text-xs font-semibold tracking-[0.2em] text-muted-foreground mb-4">Navegación</h4>
            <div className="flex flex-col gap-2">
              <Link to="/" className="text-sm text-foreground/80 hover:text-primary transition-colors">Inicio</Link>
              <Link to="/about" className="text-sm text-foreground/80 hover:text-primary transition-colors">Nosotros</Link>
              <Link to="/services" className="text-sm text-foreground/80 hover:text-primary transition-colors">Servicios</Link>
              <Link to="/catalog" className="text-sm text-foreground/80 hover:text-primary transition-colors">Catálogo</Link>
            </div>
          </div>
          <div>
            <h4 className="font-display text-xs font-semibold tracking-[0.2em] text-muted-foreground mb-4">Contacto</h4>
            <div className="flex flex-col gap-2 text-sm text-foreground/80">
              <p>Calle de ejemplo, Palma</p>
              <p>971 000 000</p>
              <p>info@flordaroma.com</p>
            </div>
          </div>
          <div>
            <h4 className="font-display text-xs font-semibold tracking-[0.2em] text-muted-foreground mb-4">Horario</h4>
            <div className="flex flex-col gap-2 text-sm text-foreground/80">
              <p>Lun – Vie: 9:00 – 20:00</p>
              <p>Sábados: 9:00 – 14:00</p>
            </div>
          </div>
        </div>
        <div className="mt-12 pt-8 border-t border-border text-center text-xs tracking-widest text-muted-foreground uppercase">
          © {new Date().getFullYear()} Flor d'Aroma — Palma de Mallorca
        </div>
      </div>
    </footer>
  );
}
