import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { to: "/" as const, label: "Inicio" },
  { to: "/about" as const, label: "Nosotros" },
  { to: "/services" as const, label: "Servicios" },
  { to: "/catalog" as const, label: "Catálogo" },
  { to: "/shop" as const, label: "Tienda" },
  { to: "/contact" as const, label: "Contacto" },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          <Link to="/" className="font-display text-2xl sm:text-3xl font-bold tracking-widest text-primary uppercase">
            Flor d'Aroma
          </Link>

          <nav className="hidden md:flex items-center gap-0">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="px-4 py-2 text-xs font-display tracking-[0.2em] uppercase text-muted-foreground hover:text-primary transition-colors"
                activeProps={{ className: "px-4 py-2 text-xs font-display tracking-[0.2em] uppercase text-primary" }}
              >
                {link.label}
              </Link>
            ))}
          </nav>

          <button
            className="md:hidden p-2 text-foreground"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <nav className="md:hidden bg-background border-b border-border px-4 pb-4">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="block py-3 text-xs font-display tracking-[0.2em] uppercase text-muted-foreground hover:text-primary transition-colors"
              activeProps={{ className: "block py-3 text-xs font-display tracking-[0.2em] uppercase text-primary" }}
              onClick={() => setMobileOpen(false)}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      )}
    </header>
  );
}
